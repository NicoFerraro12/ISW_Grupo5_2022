import { useState } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
} from "react-router-dom";
import Header from "./components/common/Header";
import Home from "./components/page/Home";
import LoQueSea from "./components/page/LoQueSea";


function App() {
  const [dataPedido, setDataPedido] = useState(null);
  const [inicioSesion, setInicioSesion] = useState(false);
  return (
    <div>
      <Router>
      <Header inicioSesion={inicioSesion} setInicioSesion={setInicioSesion}/>
        <Routes>
          <Route path="/*" element={<Home dataPedido={dataPedido} setDataPedido={setDataPedido} inicioSesion={inicioSesion}/>}
            />
          <Route path="/loQueSea" element={<LoQueSea dataPedido={dataPedido} setDataPedido={setDataPedido}/>}
            />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
