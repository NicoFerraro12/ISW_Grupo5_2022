import React, { useState } from 'react'
import { Grid, Typography } from '@mui/material'
import Inputs from '../common/Inputs'
import imgMaps from '../../../src/assets/LoQueSea/mapa.png'
import CustomButtom from '../common/CustomButtom'
import { useNavigate } from 'react-router-dom'
import CustomSelect from '../common/CustomSelect'
import UpdateFile from '../common/UpdateFile'

const DatosOrigen = ({setActiveStep, setDataPedido, dataPedido, activeStep}) => {
  const [pesoArchivo, setPesoArchivo] = useState(0)
  let navigate = useNavigate();
  const [inputs, setInputs] = useState([
    {
      error:false,
      value: dataPedido && dataPedido.producto ? dataPedido.producto : '',
      requerido:true,
      name:'producto'
    },
    {
      error:false,
      value:'',
      requerido:false,
      name:'img'
    },
    {
      error:false,
      value: dataPedido && dataPedido.ciudadOrigen ? dataPedido.ciudadOrigen : '',
      requerido:true,
      name:'ciudadOrigen'
    },
    {
      error:false,
      value: dataPedido && dataPedido.calleOrigen ? dataPedido.calleOrigen : '',
      requerido:true,
      name:'calleOrigen'
    },
   {
      error:false,
      value: dataPedido && dataPedido.nroOrigen ? dataPedido.nroOrigen : '',
      requerido:true,
      name: 'nroOrigen'
    },
    {
      error:false,
      value: dataPedido && dataPedido.referenciaOrigen ? dataPedido.referenciaOrigen : '',
      requerido:false,
      name:'referenciaOrigen'
    },
  ])
  const onChangeInputs = (e) =>{
    const dataActualizada =  inputs.map(data =>{
      if(data.name === [e.target.name].toString()){
        return {...data, error: false, value:e.target.value}
      }else{
        return data
      }
    })
    setInputs(dataActualizada)
  }

  const handleCancelar = () => {
    setDataPedido(null)
    navigate('/')
  }
  const validarFormulario = () => {
    let valido = true
    const datosValidados = inputs.map(data => {
      if(data.value === '' && data.requerido === true){
        valido = false
        return {...data, error:true}
      }else{
        return data
      }
    })
    if(valido === false){
      setInputs(datosValidados)
    }
    if(pesoArchivo > 5){
      valido = false
    }
    return valido
  }

  const handleAceptar = () => {
    if(validarFormulario()){
      setDataPedido({
        ...dataPedido,
        pantalla: activeStep,
        producto:inputs[0].value,
        ciudadOrigen:inputs[2].value,
        calleOrigen:inputs[3].value,
        nroOrigen:inputs[4].value,
        referenciaOrigen:inputs[5].value,
      })
      setActiveStep(data => data +1)
    }
  }

  const handleImagen = () => {

    const direccionSeleccionada = inputs.map(data => {
      if(data.name === 'ciudadOrigen' ){
        return {...data, value:1, error: false}
      }else if (data.name === 'calleOrigen'){
        return  {...data, value:'Bv.Chacabuco', error: false}
      }else if(data.name === 'nroOrigen'){
        return  {...data, value:'458', error: false}
      }else{
        return data
      }
    })
    setInputs(direccionSeleccionada)
  }
  return (
      <Grid container mt={1} direction="row" rowSpacing={1}>
            <Grid item xs={12}>
              <Typography  style={{fontWeight:'bold', fontFamily:'Bitter', fontSize:'27px'}}>
              ¿Qué necesitás?
              </Typography>
            </Grid>
            <Grid item xs={6}>
              <Inputs
                name={'producto'}
                defaultValue={inputs[0].value}
                value={inputs[0].value}
                error={inputs[0].error} 
                label={'¿Qué llevamos?*'}
                fullWidth={true}
                //helperText={'*Requerido'}
                onChange={onChangeInputs} 
              />
            </Grid>
            <Grid item xs={2}>
              
            </Grid>
            <Grid item xs={3}>
              <UpdateFile pesoArchivo={pesoArchivo} setPesoArchivo={setPesoArchivo} />
            </Grid>
            <Grid item xs={12} mt={2}>
              <Typography noWrap style={{fontWeight:'bold', fontFamily:'Bitter', fontSize:'21px'}}>
              ¿Dónde lo buscamos?
              </Typography>
            </Grid>
            <Grid item container >
              <Grid item container xs={6}>
                <Grid item xs={12}>
                  <CustomSelect
                    name={'ciudadOrigen'}
                    value={inputs[2].value}
                    label={'Ciudad*'}
                    fullWidth={true}
                    onChange={onChangeInputs} 
                    error={inputs[2].error} 
                  />
                </Grid>
                <Grid item xs={7} >
                  <Inputs
                    name={'calleOrigen'}
                    defaultValue={inputs[3].value}
                    value={inputs[3].value}
                    error={inputs[3].error} 
                    label={'Calle*'}
                    fullWidth={true}
                    //helperText={'*Requerido'}
                    onChange={onChangeInputs} 
                  />
                </Grid>
                <Grid item xs={1}>
                  
                </Grid>
                <Grid item xs={4}>
                  <Inputs
                    name={'nroOrigen'}
                    defaultValue={inputs[4].value}
                    value={inputs[4].value}
                    error={inputs[4].error} 
                    label={'Nro*'}
                    fullWidth={true}
                    type={'number'}
                    //helperText={'*Requerido'}
                    onChange={onChangeInputs} 
                  />
                </Grid>
                <Grid item xs={12}>
                  <Inputs
                    name={'referenciaOrigen'}
                    defaultValue={inputs[5].value}
                    value={inputs[5].value}
                    error={inputs[5].error} 
                    label={'Referencia'}
                    fullWidth={true}
                    //helperText={'*Requerido'}
                    onChange={onChangeInputs} 
                  />
                </Grid>
                <Grid item container  xs={12}>
                  <Grid item xs={5} >
                    <CustomButtom 
                      label={'Cancelar'} 
                      variant={'contained'} 
                      style={{backgroundColor: '#fff', color:'grey', borderRadius:'20px', border:'1px solid #CBCBCB', width:'120px'}}
                      onClick={handleCancelar}
                      />
                  </Grid>
                  <Grid item xs={7}>
                    <CustomButtom 
                      label={'Siguiente'} 
                      variant={'contained'} 
                      style={{backgroundColor: '#F15F37', borderRadius:'20px', width:'150px'}} 
                      onClick={handleAceptar}/>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item xs={1}>
                
              </Grid>
              <Grid item xs={5}>
                <img src={imgMaps} alt='Google Maps' style={{height:'93%', border:'1px solid #F15F37', cursor:'pointer'}} onClick={handleImagen}/>
              </Grid>
            </Grid>
      </Grid>
  )
}

export default DatosOrigen