import { Grid, Typography } from '@mui/material'
import React from 'react'
import { useNavigate } from 'react-router-dom';
import CustomButtom from '../common/CustomButtom'


const Resumen = ({setActiveStep, setDataPedido, dataPedido, activeStep}) => {
  
  let navigate = useNavigate();

  console.log(dataPedido);

  const verificarCiudad = (data) => {
    if(data===1){
      return 'Córdoba'
    } else if(data===2){
      return 'Carlos Paz'
    } else{
      return 'Villa Allende'
    }
  }


  const mostrarDomicilioOrigen = () => {
    return `${dataPedido && dataPedido.calleOrigen} ${dataPedido && dataPedido.nroOrigen}, ${dataPedido && verificarCiudad(dataPedido.ciudadOrigen)}, Córdoba`
  } 
  const mostrarDomicilioDestino = () => {
    return `${dataPedido && dataPedido.calleDestino} ${dataPedido && dataPedido.nroDestino}, ${dataPedido && verificarCiudad(dataPedido.ciudadDestino)}, Córdoba`
  } 
  
  const handleAceptar = () => {
    navigate('/')
    setDataPedido(null)
  } 

  const handleCancelar = () => {
    navigate('/')
    setDataPedido(null)
  }
  return (
    <Grid container mt={0} alignItems='center' justifyItems={'center'} justifyContent='center' direction="row" columnSpacing={1} rowSpacing={0}>
      <Grid item xs={3}>
        
      </Grid>
      <Grid item xs={9} mb={1} >
        <Typography  style={{fontWeight:'bold', fontFamily:'Bitter', fontSize:'30px'}}>
          Resumen
        </Typography>
      </Grid>
      
      <Grid item xs={3}>
        
      </Grid>
      <Grid item xs={9} mb={2} >
        <Typography  style={{fontFamily:'Bitter', fontSize:'18px'}}>
        Revisá tu pedido y los datos
        </Typography>
      </Grid>
      <Grid item xs={3}>
        
      </Grid>
      <Grid item xs={9} >
        <Typography  style={{fontFamily:'Bitter', fontSize:'16px', color:'#373737', opacity:'0.5'}}>
          Llevamos
        </Typography>
      </Grid>
      <Grid item xs={3}>
        
      </Grid>
      <Grid item xs={9} >
        <Typography  style={{fontFamily:'Bitter', fontSize:'18px'}}>
          {`${dataPedido && dataPedido.producto ? dataPedido.producto : '' }`}
        </Typography>
      </Grid>
      <Grid item xs={3}>
        
      </Grid>
      <Grid item xs={9} mt={2} >
        <Typography  style={{fontFamily:'Bitter', fontSize:'16px', color:'#373737', opacity:'0.5'}}>
        Dirección de retiro
        </Typography>
      </Grid>
      <Grid item xs={3}>
        
      </Grid>
      <Grid item xs={9} >
        <Typography  style={{fontFamily:'Bitter', fontSize:'18px'}}>
          {`${dataPedido ? mostrarDomicilioOrigen() : '' }`}
        </Typography>
      </Grid>
      <Grid item xs={3}>
        
      </Grid>
      <Grid item xs={9} mt={2} >
        <Typography  style={{fontFamily:'Bitter', fontSize:'16px', color:'#373737', opacity:'0.5'}}>
        Dirección de entrega
        </Typography>
      </Grid>
      <Grid item xs={3}>
        
      </Grid>
      <Grid item xs={9} >
        <Typography  style={{fontFamily:'Bitter', fontSize:'18px'}}>
          {`${dataPedido ? mostrarDomicilioDestino() : '' }`}
        </Typography>
      </Grid>
      <Grid item xs={3}>
        
      </Grid>
      <Grid item xs={9} mt={2} >
        <Typography  style={{fontFamily:'Bitter', fontSize:'16px', color:'#373737', opacity:'0.5'}}>
        Medio de pago
        </Typography>
      </Grid>
      <Grid item xs={3}>
        
      </Grid>
      <Grid item xs={9} >
        <Typography  style={{fontFamily:'Bitter', fontSize:'18px'}}>
          {`${dataPedido && dataPedido.producto ? dataPedido.tipoPago : '' }`}
        </Typography>
      </Grid>
      <Grid item xs={3}>
        
      </Grid>
      <Grid item xs={9} mt={2} >
        <Typography  style={{fontFamily:'Bitter', fontSize:'16px', color:'#373737', opacity:'0.5'}}>
          Total
        </Typography>
      </Grid>
      <Grid item xs={3}>
        
      </Grid>
      <Grid item xs={9} >
        <Typography  style={{fontFamily:'Bitter', fontSize:'18px'}}>
          Total : {`$${dataPedido && dataPedido.producto ? dataPedido.totalPagar : '' }`}
        </Typography>
      </Grid>
      
      <Grid item xs={3} >
        
      </Grid>
      <Grid item xs={3} >
          <CustomButtom 
            label={'Cancelar'} 
            variant={'contained'} 
            style={{backgroundColor: '#fff', color:'grey', borderRadius:'20px', border:'1px solid #CBCBCB', width:'110px', marginLeft:'100px'}}
            onClick={handleCancelar}
            />
        </Grid>
      <Grid item xs={5} >
        <CustomButtom 
          label={'Confirmar'} 
          variant={'contained'} 
          style={{backgroundColor: '#F15F37', borderRadius:'20px', width:'140px', marginLeft:'50px'}} 
          onClick={handleAceptar}/>
      </Grid>
        
      <Grid item xs={1}>
      
      </Grid>
    </Grid>
  )
}

export default Resumen