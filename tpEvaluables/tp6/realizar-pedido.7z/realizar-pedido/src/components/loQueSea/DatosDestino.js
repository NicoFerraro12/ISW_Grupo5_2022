import { FormControlLabel, Grid, Radio, Typography } from '@mui/material'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import CustomButtom from '../common/CustomButtom';
import CustomSelect from '../common/CustomSelect';
import Inputs from '../common/Inputs'

const DatosDestino = ({setActiveStep, setDataPedido, dataPedido, activeStep}) => {
  let navigate = useNavigate();

  const [inputs, setInputs] = useState([
    {
      error:false,
      value: dataPedido && dataPedido.ciudadDestino ? dataPedido.ciudadDestino : '',
      requerido:true,
      name:'ciudadDestino'
    },
    {
      error:false,
      value:dataPedido && dataPedido.calleDestino ? dataPedido.calleDestino : '',
      requerido:true,
      name:'calleDestino'
    },
    {
       error:false,
       value: dataPedido && dataPedido.nroDestino ? dataPedido.nroDestino : '',
       requerido:true,
       name: 'nroDestino'
     },
     {
       error:false,
       value: dataPedido && dataPedido.referenciaDestino ? dataPedido.referenciaDestino : '',
       requerido:false,
       name:'referenciaDestino'
     },
     {
       name:'totalPagar',
       value:0
      },
      {
        error:false,
        value: dataPedido && dataPedido.fechaPedido ? dataPedido.fechaPedido : '',
        requerido:false,
        name:'fechaPedido'
      },
      {
        error:false,
        value: dataPedido && dataPedido.tipoEnvio ? dataPedido.tipoEnvio : 'antesPosible',
        requerido:false,
        name:'tipoEnvio'
      },
    
  ])
  const onChangeInputs = (e) =>{
    const dataActualizada =  inputs.map(data =>{
      if(data.name === [e.target.name].toString()){
        return {...data, error: false, value:e.target.value}
      }else{
        return data
      }
    })
    setInputs(dataActualizada)
  }

  const handleCancelar = () => {
    navigate('/')
    setDataPedido(null)
  }

  const validarFormulario = () => {
    let valido = true
    const datosValidados = inputs.map(data => {
      if((data.value === '' && data.requerido === true) || (data.value === '' && data.name==='fechaPedido' && inputs[6].value==='fecha')){
        valido = false
        return {...data, error:true}
      }else{
        return data
      }
    })
    if(valido === false){
      setInputs(datosValidados)
    }
    return valido
  }

  const handleAceptar = () => {
    if(validarFormulario()){
      setDataPedido({
        ...dataPedido,
        pantalla: activeStep,
        ciudadDestino:inputs[0].value,
        calleDestino:inputs[1].value,
        nroDestino:inputs[2].value,
        referenciaDestino:inputs[3].value,
        totalPagar:inputs[4].value,
        tipoEnvio:inputs[6].value,
        fechaPedido:inputs[5].value,

      })
      setActiveStep(data => data +1)
    }
  }

  const calcularCostoEnvio = (ciudad) =>{
    if(ciudad === 1){
      return 150
    }
    if(ciudad === 2){
      return 280
    }
    if(ciudad === 3){
      return 460
    }else{
      return 0
    }
  }

  useEffect(() => {
    if(inputs && inputs[0].value !== ''){
      const valor = calcularCostoEnvio(parseInt(inputs[0].value));
      const dataActualizada =  inputs.map(data =>{
        if(data.name === inputs[4].name){
          return {...data, value: valor.toString()}
        }else{
          return data
        }
      })
      setInputs(dataActualizada)
    }
  }, [inputs[0]])

console.log(inputs,'inputs')
  return (
    <Grid container mt={0} alignItems='center' justifyItems={'center'} justifyContent='center' direction="row" columnSpacing={1} rowSpacing={1}>
            <Grid item xs={3}>
              
            </Grid>
            <Grid item xs={9}>
              <Typography  style={{fontWeight:'bold', fontFamily:'Bitter', fontSize:'27px'}}>
              ¿A donde lo llevamos?
              </Typography>
            </Grid>
            <Grid item xs={3} >
              
            </Grid>
            <Grid item xs={6} >
              <CustomSelect
                      name={'ciudadDestino'}
                      value={inputs[0].value}
                      label={'Ciudad*'}
                      fullWidth={true}
                      onChange={onChangeInputs} 
                      error={inputs[0].error} 
                    />
              </Grid>
            <Grid item xs={3}>
              
            </Grid>
            <Grid item xs={3}>
              
            </Grid>
            <Grid item xs={4} >
                  <Inputs
                    name={'calleDestino'}
                    defaultValue={inputs[1].value}
                    value={inputs[1].value}
                    error={inputs[1].error} 
                    label={'Calle*'}
                    fullWidth={true}
                    //helperText={'*Requerido'}
                    onChange={onChangeInputs} 
                  />
                </Grid>
                
                <Grid item xs={2}>
                  <Inputs
                    name={'nroDestino'}
                    defaultValue={inputs[2].value}
                    value={inputs[2].value}
                    error={inputs[2].error} 
                    label={'Nro*'}
                    fullWidth={true}
                    type={'number'}
                    //helperText={'*Requerido'}
                    onChange={onChangeInputs} 
                  />
                </Grid>
                <Grid item xs={3}>
                  
                </Grid>
                <Grid item xs={3} >
              
                </Grid>
                <Grid item xs={6} >
                  <Inputs
                      name={'referenciaDestino'}
                      defaultValue={inputs[3].value}
                      value={inputs[3].value}
                      error={inputs[3].error} 
                      label={'Referencia'}
                      fullWidth={true}
                      //helperText={'*Requerido'}
                      onChange={onChangeInputs} 
                    />
                </Grid>
                <Grid item xs={3}>
                
                </Grid>
                <Grid item xs={3}>
              
                </Grid>
                <Grid item xs={9}>
                  <Typography  style={{fontWeight:'bold', fontFamily:'Bitter', fontSize:'20px',color:'#F15F37'}}>
                    Total a pagar :<span style={{fontWeight:'bold', fontFamily:'Bitter', fontSize:'20px',color:'black'}}> ${inputs[4].value}</span>
                  </Typography>
                </Grid>
                <Grid item xs={3}>
              
                </Grid>
                <Grid item xs={9}>
                  <Typography  style={{fontWeight:'bold', fontFamily:'Bitter', fontSize:'22px'}}>
                  ¿Cuando llevamos el pedido?
                  </Typography>
                </Grid>
                
                <Grid item xs={3}>
                    
                </Grid>
                <Grid item xs={3}>
                  <FormControlLabel
                      checked={inputs[6].value === 'antesPosible'}
                      value={'antesPosible'}
                      name={'tipoEnvio'}
                      onChange={onChangeInputs}
                      control={<Radio sx={{
                      '&.Mui-checked': {
                        color: '#F15F37',
                      },
                      }}/>}
                      label={<div style={{ fontSize: '14px', fontWeight:'bold' }}>{'Lo antes posible'}</div>}
                      
                    />
                  </Grid>
                <Grid item xs={6}>
                  <FormControlLabel
                        
                        checked={inputs[6].value === 'fecha'}
                        value={'fecha'}
                        name={'tipoEnvio'}
                        onChange={onChangeInputs}
                        control={<Radio sx={{
                        '&.Mui-checked': {
                          color: '#F15F37',
                        },
                        }}/>}
                        label={<Inputs
                          disabled={inputs[6].value === 'fecha'? false : true}
                          name={'fechaPedido'}
                          defaultValue={inputs[3].value}
                          value={inputs[5].value}
                          error={inputs[5].error} 
                          //label={'Fecha'}
                          fullWidth={true}
                          //helperText={'*Requerido'}
                          onChange={onChangeInputs} 
                          type={'datetime-local'}
                      />}
                        
                      />
                </Grid>
                <Grid item xs={1}  >
                    
                </Grid>
                <Grid item xs={3} mt={3}>
                    <CustomButtom 
                      label={'Cancelar'} 
                      variant={'contained'} 
                      style={{backgroundColor: '#fff', color:'grey', borderRadius:'20px', border:'1px solid #CBCBCB', width:'110px', marginLeft:'100px'}}
                      onClick={handleCancelar}
                      />
                  </Grid>
                <Grid item xs={5} mt={3} >
                  <CustomButtom 
                    label={'Siguiente'} 
                    variant={'contained'} 
                    style={{backgroundColor: '#F15F37', borderRadius:'20px', width:'115px', marginLeft:'50px'}} 
                    onClick={handleAceptar}/>
                </Grid>
                  
                <Grid item xs={1}>
                
                </Grid>
      </Grid>
  )
}

export default DatosDestino