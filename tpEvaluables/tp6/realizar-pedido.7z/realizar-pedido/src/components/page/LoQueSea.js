import { Grid } from '@mui/material'
import React, {useState} from 'react'
import Navegacion from '../common/Navegacion'
import DatosDestino from '../loQueSea/DatosDestino';
import DatosOrigen from '../loQueSea/DatosOrigen';
import MetodoDePago from '../loQueSea/MetodoDePago';
import Resumen from '../loQueSea/Resumen';

const LoQueSea = ({setDataPedido, dataPedido}) => {
  const steps = [
    'DatosOrigen',
    'DatosDestino',
    'Pago',
    'Detalle',
  ];
  const [activeStep, setActiveStep] = useState(0)
  console.log(activeStep,'activeStep')
  return (
    <Grid container mt={2} alignItems={'center'} direction="row" justifyContent={'center'} rowSpacing={1}>
      <Grid item xs={10}>
        <Navegacion activeStep={activeStep} steps={steps}/>
      </Grid>
      <Grid item container xs={6}>
        {activeStep === 0 ? 
          <DatosOrigen
            setActiveStep={setActiveStep}
            activeStep={activeStep}
            setDataPedido={setDataPedido}
            dataPedido={dataPedido}
          />
        : activeStep === 1 ?
          <DatosDestino
            setActiveStep={setActiveStep}
            activeStep={activeStep}
            setDataPedido={setDataPedido} 
            dataPedido={dataPedido}
          />
        : activeStep === 2 ?
          <MetodoDePago
            setActiveStep={setActiveStep}
            activeStep={activeStep}
            setDataPedido={setDataPedido}
            dataPedido={dataPedido}
          />
        :
          <Resumen
            setActiveStep={setActiveStep}
            activeStep={activeStep}
            setDataPedido={setDataPedido}
            dataPedido={dataPedido}
          />
        }
      </Grid>
    </Grid>
  )
}

export default LoQueSea