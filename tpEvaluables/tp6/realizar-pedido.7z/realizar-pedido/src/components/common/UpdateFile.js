import React, { useState } from 'react'

import { styled } from '@mui/material/styles';
import Button from '@mui/material/Button';
import { Typography } from '@mui/material';

const Input = styled('input')({
  display: 'none',
});


const UpdateFile = ({setPesoArchivo, pesoArchivo}) => {
  const [file, setFile] = useState(null)

  const handleFiles = (e) => {
    const file = e.target.files[0]
    if(file){
      setFile(file)
      setPesoArchivo(parseInt((file.size / 1000000).toFixed(2)))
    }else{
      setFile(null)
    }
  }
  console.log(file)

  console.log(file)
  return (
    <label htmlFor="contained-button-file">
      <Input accept="image/*" id="contained-button-file" type="file" onChange={handleFiles}/>
      <Button style={{backgroundColor:'#F15F37'}} variant="contained" component="span">
        {file && file !== null ?' IMAGEN SUBIDA': 'Subir Imagen'}
      </Button>
      <Typography mt={1} ml={1} style={{fontWeight:'bold', color:`${pesoArchivo > 5 ? 'red': 'bleck'}`, fontFamily:'Bitter', fontSize:'15px'}}>
        {file ? `Peso ${(file.size / 1000000).toFixed(2)} MB` : ''}
      </Typography>
    </label>
  )
}

export default UpdateFile
