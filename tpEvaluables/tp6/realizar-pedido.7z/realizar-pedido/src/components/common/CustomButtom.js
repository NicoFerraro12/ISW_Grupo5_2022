import { Button } from '@mui/material'
import React from 'react'

const CustomButtom = ({variant, label, style, onClick}) => {
  return (
    <Button style={style} variant={variant} onClick={onClick}> {label}</Button>
  )
}

export default CustomButtom